//
//  boy.swift
//  GGG-GGJ2018
//
//  Created by Nina Demirjian on 1/27/18.
//  Copyright © 2018 Elliot Richard John Winch. All rights reserved.
//

import Foundation
import SpriteKit


public class boy : NSObject {
    
    var name : String!
    var age : Int!
    var bio : String!
    var image : String!
    var profPic : SKLabelNode!
    
    
    init(myName: String, myAge : Int, myBio : String, myImage : String){
        name = myName
        age = myAge
        bio = myBio
        image = myImage
    }
    
    
    
    
}

